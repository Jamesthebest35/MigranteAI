
import type { Testimonial } from './types';

export const LANGUAGES = [
    'English', 'Español'
];

export const getFeatures = (t: (key: string) => string) => [
    {
        icon: 'ChatIcon',
        title: t('features.chat.title'),
        description: t('features.chat.description'),
        linkText: t('features.chat.linkText'),
        linkHref: '#chat',
        color: 'blue',
    },
    {
        icon: 'ResourcesIcon',
        title: t('features.resources.title'),
        description: t('features.resources.description'),
        linkText: t('features.resources.linkText'),
        linkHref: '#resources',
        color: 'orange',
    },
    {
        icon: 'TranslateIcon',
        title: t('features.translate.title'),
        description: t('features.translate.description'),
        linkText: t('features.translate.linkText'),
        linkHref: '#translate',
        color: 'green',
    }
];

export const getTestimonials = (t: (key: string) => string): Testimonial[] => [
    {
        name: 'Maria G.',
        avatarUrl: 'https://picsum.photos/200?random=101',
        rating: 5,
        quote: t('testimonials.data.maria.quote'),
    },
    {
        name: 'Ahmed K.',
        avatarUrl: 'https://picsum.photos/200?random=102',
        rating: 4,
        quote: t('testimonials.data.ahmed.quote'),
    },
    {
        name: 'Wei L.',
        avatarUrl: 'https://picsum.photos/200?random=103',
        rating: 5,
        quote: t('testimonials.data.wei.quote'),
    }
];
