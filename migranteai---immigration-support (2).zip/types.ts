export interface ChatMessage {
    role: 'user' | 'model';
    text: string;
}

export interface Testimonial {
    name: string;
    avatarUrl: string;
    rating: number;
    quote: string;
}

export interface LinkResource {
    name: string;
    url: string;
    description: string;
    category: string;
}
