// FIX: Implemented the main App component to resolve import errors.
import React from 'react';
import Header from './components/Header';
import HeroSection from './components/HeroSection';
import TrustIndicators from './components/TrustIndicators';
import FeaturesSection from './components/FeaturesSection';
import ResourcesSection from './components/ResourcesSection';
import TranslationSection from './components/TranslationSection';
import TestimonialsSection from './components/TestimonialsSection';
import PricingSection from './components/PricingSection';
import Footer from './components/Footer';
import DemoHub from './components/DemoHub';
import { useAuth } from './contexts/AuthContext';

const App: React.FC = () => {
  const { isDemo } = useAuth();
  return (
    <div className="bg-white font-sans text-neutral-800">
      <Header />
      <main>
        <HeroSection />
        <TrustIndicators />
        <FeaturesSection />
        <ResourcesSection />
        <TranslationSection />
        <TestimonialsSection />
        <PricingSection />
      </main>
      <Footer />
      {isDemo && <DemoHub />}
    </div>
  );
};

export default App;