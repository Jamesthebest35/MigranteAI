
import React from 'react';
import { useTranslation } from '../contexts/LanguageContext';

const TrustIndicators: React.FC = () => {
    const { t } = useTranslation();
    const indicators = [
        { value: '10,000+', label: t('trustIndicators.immigrantsHelped') },
        { value: '150+', label: t('trustIndicators.resourcesAvailable') },
        { value: '24/7', label: t('trustIndicators.supportAvailable') },
    ];

    return (
        <section className="bg-white py-8">
            <div className="container mx-auto px-4">
                <div className="flex flex-col md:flex-row justify-center items-center space-y-6 md:space-y-0 md:space-x-16">
                    {indicators.map((indicator, index) => (
                        <div key={index} className="text-center">
                            <div className="text-3xl font-bold text-primary">{indicator.value}</div>
                            <div className="text-neutral-600">{indicator.label}</div>
                        </div>
                    ))}
                </div>
            </div>
        </section>
    );
};

export default TrustIndicators;
