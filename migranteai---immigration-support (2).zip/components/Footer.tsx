
import React from 'react';
import { useTranslation } from '../contexts/LanguageContext';

const Footer: React.FC = () => {
    const { t } = useTranslation();
    return (
        <footer className="bg-neutral-800 text-white">
            <div className="container mx-auto px-4 py-12">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                    <div>
                        <div className="flex items-center space-x-2 mb-4">
                            <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center text-primary font-bold text-xl">M</div>
                            <span className="text-xl font-bold">MigranteAI</span>
                        </div>
                        <p className="text-neutral-300 text-sm">{t('footer.tagline')}</p>
                    </div>
                    <div>
                        <h4 className="font-bold mb-4">{t('footer.features.title')}</h4>
                        <ul className="space-y-2 text-sm text-neutral-300">
                            <li><a href="#chat" className="hover:text-secondary">{t('footer.features.chat')}</a></li>
                            <li><a href="#resources" className="hover:text-secondary">{t('footer.features.resources')}</a></li>
                            <li><a href="#translate" className="hover:text-secondary">{t('footer.features.translate')}</a></li>
                        </ul>
                    </div>
                    <div>
                        <h4 className="font-bold mb-4">{t('footer.legal.title')}</h4>
                        <ul className="space-y-2 text-sm text-neutral-300">
                            <li><a href="#" className="hover:text-secondary">{t('footer.legal.privacy')}</a></li>
                            <li><a href="#" className="hover:text-secondary">{t('footer.legal.terms')}</a></li>
                            <li><a href="#" className="hover:text-secondary">{t('footer.legal.disclaimer')}</a></li>
                        </ul>
                    </div>
                    <div>
                        <h4 className="font-bold mb-4">{t('footer.contact.title')}</h4>
                        <ul className="space-y-2 text-sm text-neutral-300">
                            <li><a href="#" className="hover:text-secondary">support@migranteai.com</a></li>
                        </ul>
                    </div>
                </div>
                <div className="border-t border-neutral-600 mt-10 pt-6 text-center text-sm text-neutral-400">
                    <p>&copy; {new Date().getFullYear()} MigranteAI. {t('footer.copyright')}</p>
                    <p className="mt-2 text-xs">{t('footer.legalDisclaimer')}</p>
                </div>
            </div>
        </footer>
    );
};

export default Footer;
