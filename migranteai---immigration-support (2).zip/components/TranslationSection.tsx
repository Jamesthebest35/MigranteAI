// FIX: Implemented the TranslationSection component to resolve import errors.
import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { useTranslation } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { translateDocument } from '../services/geminiService';
import UploadIcon from './icons/UploadIcon';
import LockIcon from './icons/LockIcon';

interface TranslationSectionProps {
    isDemoInstance?: boolean;
}

const DemoOverlay: React.FC = () => {
    const { t } = useTranslation();
    const { startDemo } = useAuth();
    return (
        <div className="absolute inset-0 bg-neutral-50/50 backdrop-blur-sm rounded-xl z-10 flex flex-col items-center justify-center p-4 text-center">
            <h4 className="font-bold text-xl text-neutral-800">{t('translation.demo.title')}</h4>
            <p className="text-neutral-600 my-2 max-w-md">{t('translation.demo.description')}</p>
            <button 
                onClick={startDemo}
                className="bg-secondary hover:bg-orange-700 text-white font-bold py-2 px-5 rounded-lg transition-colors duration-300 mt-2"
            >
                {t('demo.try')}
            </button>
        </div>
    );
};

const TranslationTool: React.FC = () => {
    const { t } = useTranslation();
    const [fileContent, setFileContent] = useState<string | null>(null);
    const [translatedContent, setTranslatedContent] = useState<string | null>(null);
    const [fileName, setFileName] = useState<string | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [fromLang, setFromLang] = useState('auto');
    const [toLang, setToLang] = useState('English');

    const onDrop = useCallback((acceptedFiles: File[]) => {
        const file = acceptedFiles[0];
        if (file) {
            setFileName(file.name);
            const reader = new FileReader();
            reader.onload = (e) => {
                const text = e.target?.result as string;
                setFileContent(text);
                setTranslatedContent(null);
                setError(null);
            };
            reader.readAsText(file);
        }
    }, []);

    const { getRootProps, getInputProps, isDragActive } = useDropzone({
        onDrop,
        accept: {
            'text/plain': ['.txt'],
            'text/markdown': ['.md'],
            'text/html': ['.html', '.htm'],
        },
        maxFiles: 1,
    });
    
    const handleTranslate = async () => {
        if (!fileContent) return;
        setIsLoading(true);
        setError(null);
        setTranslatedContent(null);
        try {
            const result = await translateDocument(fileContent, fromLang, toLang);
            setTranslatedContent(result);
        } catch (err) {
            setError(t('translation.error'));
            console.error(err);
        } finally {
            setIsLoading(false);
        }
    };

    const handleDownload = () => {
        if (!translatedContent) return;
        const blob = new Blob([translatedContent], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `translated_${fileName || 'document.txt'}`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };

    return (
        <div className="max-w-4xl mx-auto bg-neutral-50 rounded-xl shadow-sm p-8 border border-neutral-200">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
                {/* Upload and Original */}
                <div>
                    <label className="font-bold text-lg mb-2 block">{t('translation.originalDocument')}</label>
                    {fileContent ? (
                        <div className="bg-white p-4 rounded-lg border h-72 overflow-y-auto text-sm">
                            <p className="font-semibold mb-2 text-primary">{fileName}</p>
                            <pre className="whitespace-pre-wrap font-sans">{fileContent}</pre>
                        </div>
                    ) : (
                        <div {...getRootProps()} className={`border-2 border-dashed rounded-lg p-12 text-center cursor-pointer h-72 flex flex-col justify-center items-center transition-colors ${isDragActive ? 'border-primary bg-blue-50' : 'border-gray-300 bg-white'}`}>
                            <input {...getInputProps()} />
                            <UploadIcon className="h-12 w-12 text-gray-400 mb-4" />
                            <p className="text-neutral-600">{t('translation.dragAndDrop')}</p>
                            <p className="text-xs text-neutral-500 mt-1">{t('translation.supportedFiles')}</p>
                        </div>
                    )}
                </div>
                
                {/* Translation */}
                <div>
                    <label className="font-bold text-lg mb-2 block">{t('translation.translatedDocument')}</label>
                    <div className="bg-white p-4 rounded-lg border h-72 overflow-y-auto text-sm">
                        {isLoading ? (
                            <div className="flex items-center justify-center h-full text-neutral-500">
                                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                </svg>
                                <span>{t('translation.translating')}</span>
                            </div>
                        ) : translatedContent ? (
                            <pre className="whitespace-pre-wrap font-sans">{translatedContent}</pre>
                        ) : (
                            <div className="flex items-center justify-center h-full text-neutral-400">
                                <p>{t('translation.translationWillAppearHere')}</p>
                            </div>
                        )}
                    </div>
                </div>
            </div>
            
            <div className="mt-6 flex flex-col md:flex-row justify-between items-center gap-4">
                <div className="flex items-center space-x-2 text-sm text-neutral-500">
                    <LockIcon className="h-4 w-4" />
                    <span>{t('translation.secure')}</span>
                </div>
                <div className="flex items-center gap-4">
                    <button 
                        onClick={handleTranslate}
                        disabled={!fileContent || isLoading}
                        className="bg-primary hover:bg-blue-800 text-white font-bold py-2 px-6 rounded-lg transition-colors duration-300 disabled:bg-primary/50 disabled:cursor-not-allowed"
                    >
                       {t('translation.translateButton')}
                    </button>
                    {translatedContent && (
                        <button
                            onClick={handleDownload}
                            className="bg-secondary hover:bg-orange-700 text-white font-bold py-2 px-6 rounded-lg transition-colors duration-300"
                        >
                            {t('translation.downloadButton')}
                        </button>
                    )}
                </div>
            </div>
            {error && <p className="text-red-500 text-sm mt-4 text-center">{error}</p>}
        </div>
    );
};


const TranslationSection: React.FC<TranslationSectionProps> = ({ isDemoInstance = false }) => {
    const { t } = useTranslation();
    const { isPro } = useAuth();
    const showOverlay = !isPro && !isDemoInstance;

    if (isDemoInstance) {
        return <TranslationTool />;
    }

    return (
        <section id="translate" className="py-16 bg-white">
            <div className="container mx-auto px-4">
                <div className="text-center max-w-2xl mx-auto mb-12">
                    <h2 className="text-3xl font-bold mb-4">{t('translation.title')}</h2>
                    <p className="text-neutral-600 text-lg">{t('translation.description')}</p>
                </div>
                <div className="relative">
                    {showOverlay && <DemoOverlay />}
                    <div className={showOverlay ? 'blur-sm pointer-events-none' : ''}>
                        <TranslationTool />
                    </div>
                </div>
            </div>
        </section>
    );
};

export default TranslationSection;