
import React from 'react';
import Chat from './Chat';
import { useTranslation } from '../contexts/LanguageContext';

const HeroSection: React.FC = () => {
    const { t } = useTranslation();
    return (
        <section id="chat" className="bg-gradient-to-r from-primary to-blue-800 text-white py-16 md:py-24">
            <div className="container mx-auto px-4 flex flex-col md:flex-row items-center">
                <div className="md:w-1/2 mb-10 md:mb-0 md:pr-10 text-center md:text-left">
                    <h1 className="text-4xl md:text-5xl font-bold leading-tight mb-6">{t('hero.title')}</h1>
                    <p className="text-xl mb-8 opacity-90">{t('hero.subtitle')}</p>
                    <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 justify-center md:justify-start">
                        <a href="#chat" className="bg-secondary hover:bg-orange-700 text-white font-bold py-3 px-6 rounded-lg text-center transition-colors duration-300">{t('hero.ctaChat')}</a>
                        <a href="#resources" className="bg-white hover:bg-neutral-100 text-primary font-bold py-3 px-6 rounded-lg text-center transition-colors duration-300">{t('hero.ctaResources')}</a>
                    </div>
                </div>
                <div className="md:w-1/2 flex justify-center w-full">
                    <Chat />
                </div>
            </div>
        </section>
    );
};

export default HeroSection;
