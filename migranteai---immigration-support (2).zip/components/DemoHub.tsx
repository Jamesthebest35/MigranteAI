// FIX: Implemented the DemoHub component to resolve import errors.
import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useTranslation } from '../contexts/LanguageContext';
import Chat from './Chat';
import TranslationSection from './TranslationSection';
import XIcon from './icons/XIcon';
import ChatIcon from './icons/ChatIcon';
import TranslateIcon from './icons/TranslateIcon';

type ActiveTab = 'chat' | 'translate';

const DemoHub: React.FC = () => {
    const { t } = useTranslation();
    const { endDemo, upgrade, user } = useAuth();
    const [activeTab, setActiveTab] = useState<ActiveTab>('chat');

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
            <div className="bg-neutral-50 rounded-2xl shadow-2xl w-full max-w-5xl h-[90vh] flex flex-col overflow-hidden border border-neutral-200">
                {/* Header */}
                <header className="flex items-center justify-between p-4 border-b bg-white flex-shrink-0">
                    <div>
                        <h2 className="text-xl font-bold text-neutral-800">{t('demo.title')}</h2>
                        <p className="text-sm text-neutral-500">{t('demo.description')}</p>
                    </div>
                    <div className="flex items-center space-x-4">
                        <button 
                            onClick={upgrade} 
                            className="bg-secondary hover:bg-orange-700 text-white font-bold py-2 px-4 rounded-lg text-sm transition-colors duration-300"
                        >
                            {t('demo.upgrade')}
                        </button>
                        <button 
                            onClick={endDemo} 
                            className="text-neutral-500 hover:text-neutral-800"
                            aria-label={t('demo.end')}
                        >
                            <XIcon className="h-6 w-6" />
                        </button>
                    </div>
                </header>

                {/* Body */}
                <div className="flex-grow flex overflow-hidden">
                    {/* Sidebar / Tabs */}
                    <nav className="w-64 bg-white border-r p-4">
                        <ul className="space-y-2">
                            <li>
                                <button
                                    onClick={() => setActiveTab('chat')}
                                    className={`w-full flex items-center space-x-3 p-3 rounded-lg text-left font-medium transition-colors ${activeTab === 'chat' ? 'bg-primary/10 text-primary' : 'text-neutral-600 hover:bg-neutral-100'}`}
                                >
                                    <ChatIcon className="h-5 w-5" />
                                    <span>{t('demo.chatTab')}</span>
                                </button>
                            </li>
                            <li>
                                <button
                                    onClick={() => setActiveTab('translate')}
                                    className={`w-full flex items-center space-x-3 p-3 rounded-lg text-left font-medium transition-colors ${activeTab === 'translate' ? 'bg-primary/10 text-primary' : 'text-neutral-600 hover:bg-neutral-100'}`}
                                >
                                    <TranslateIcon className="h-5 w-5" />
                                    <span>{t('demo.translateTab')}</span>
                                </button>
                            </li>
                        </ul>
                    </nav>

                    {/* Content */}
                    <main className="flex-1 p-6 overflow-y-auto">
                        {activeTab === 'chat' && (
                            <div className="flex justify-center items-start">
                                <Chat isDemoInstance={true} />
                            </div>
                        )}
                        {activeTab === 'translate' && (
                            <TranslationSection isDemoInstance={true} />
                        )}
                    </main>
                </div>
            </div>
        </div>
    );
};

export default DemoHub;