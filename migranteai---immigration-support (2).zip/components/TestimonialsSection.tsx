
import React from 'react';
import type { Testimonial } from '../types';
import { getTestimonials } from '../constants';
import StarIcon from './icons/StarIcon';
import { useTranslation } from '../contexts/LanguageContext';

const TestimonialCard: React.FC<{ testimonial: Testimonial }> = ({ testimonial }) => {
    return (
        <div className="bg-neutral-50 rounded-xl p-6 h-full flex flex-col">
            <div className="flex items-center mb-4">
                <div className="w-12 h-12 rounded-full bg-gray-200 mr-4 overflow-hidden flex-shrink-0">
                    <img src={testimonial.avatarUrl} alt={testimonial.name} className="w-full h-full object-cover" />
                </div>
                <div>
                    <h4 className="font-bold">{testimonial.name}</h4>
                    <div className="flex">
                        {[...Array(5)].map((_, i) => (
                           <StarIcon key={i} className={`h-4 w-4 ${i < testimonial.rating ? 'text-yellow-400' : 'text-gray-300'}`} />
                        ))}
                    </div>
                </div>
            </div>
            <p className="text-neutral-600 text-sm flex-grow">"{testimonial.quote}"</p>
        </div>
    );
};

const TestimonialsSection: React.FC = () => {
    const { t } = useTranslation();
    const testimonials = getTestimonials(t);
    return (
        <section className="py-16 bg-white">
            <div className="container mx-auto px-4">
                <h2 className="text-3xl font-bold text-center mb-12">{t('testimonials.title')}</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {testimonials.map((testimonial, index) => (
                        <TestimonialCard key={index} testimonial={testimonial} />
                    ))}
                </div>
            </div>
        </section>
    );
};

export default TestimonialsSection;
