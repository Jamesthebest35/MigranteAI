// FIX: Implemented the PricingSection component to resolve import errors.
import React from 'react';
import { useTranslation } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import CheckCircleIcon from './icons/CheckCircleIcon';

interface PricingCardProps {
    plan: 'Community' | 'Pro';
    price: string;
    period: string;
    features: string[];
    isFeatured?: boolean;
}

const PricingCard: React.FC<PricingCardProps> = ({ plan, price, period, features, isFeatured }) => {
    const { t } = useTranslation();
    const { user, isPro, login, upgrade, startDemo } = useAuth();
    
    const CtaButton = () => {
        const primaryClass = `w-full font-bold py-3 px-6 rounded-lg text-center transition-colors duration-300 ${isFeatured ? 'bg-white text-primary hover:bg-neutral-100' : 'bg-primary text-white hover:bg-blue-800'}`;
        const secondaryClass = `w-full font-bold py-3 px-6 rounded-lg text-center transition-colors duration-300 ${isFeatured ? 'bg-primary/80 border border-white text-white hover:bg-primary' : 'bg-neutral-100 text-primary hover:bg-neutral-200'}`;

        if (!user) {
            return <button onClick={login} className={primaryClass}>{t('pricing.cta.signUp')}</button>;
        }
        if (plan === 'Pro' && !isPro) {
            return (
                <div className="space-y-3">
                    <button onClick={upgrade} className={primaryClass}>{t('pricing.cta.upgrade')}</button>
                    <button onClick={startDemo} className={secondaryClass}>{t('demo.try')}</button>
                </div>
            );
        }
        if ((plan === 'Pro' && isPro) || (plan === 'Community' && !isPro)) {
            return <button disabled className="w-full font-bold py-3 px-6 rounded-lg text-center bg-neutral-200 text-neutral-500 cursor-default">{t('pricing.cta.currentPlan')}</button>;
        }
        return <button onClick={login} className={primaryClass}>{t('pricing.cta.getStarted')}</button>;
    };

    return (
        <div className={`rounded-xl p-8 border flex flex-col ${isFeatured ? 'bg-primary text-white border-primary' : 'bg-white border-neutral-200'}`}>
            <h3 className="text-2xl font-bold">{plan}</h3>
            <p className={`mt-2 ${isFeatured ? 'text-blue-200' : 'text-neutral-600'}`}>{t(`pricing.plans.${plan.toLowerCase()}.description`)}</p>
            <div className="mt-6">
                <span className="text-4xl font-bold">{price}</span>
                <span className={`ml-2 ${isFeatured ? 'text-blue-200' : 'text-neutral-500'}`}>{period}</span>
            </div>
            <ul className="mt-8 space-y-4 flex-grow">
                {features.map((feature, index) => (
                    <li key={index} className="flex items-start">
                        <CheckCircleIcon className={`h-6 w-6 mr-3 flex-shrink-0 ${isFeatured ? 'text-white' : 'text-success'}`} />
                        <span>{feature}</span>
                    </li>
                ))}
            </ul>
            <div className="mt-10">
                <CtaButton />
            </div>
        </div>
    );
};

const PricingSection: React.FC = () => {
    const { t } = useTranslation();
    const plans = {
        community: {
            price: t('pricing.plans.community.price'),
            features: [
                t('pricing.plans.community.features.feature1'),
                t('pricing.plans.community.features.feature2'),
                t('pricing.plans.community.features.feature3'),
                t('pricing.plans.community.features.feature4'),
            ],
        },
        pro: {
            price: '$9.99',
            features: [
                t('pricing.plans.pro.features.feature1'),
                t('pricing.plans.pro.features.feature2'),
                t('pricing.plans.pro.features.feature3'),
                t('pricing.plans.pro.features.feature4'),
                t('pricing.plans.pro.features.feature5'),
            ],
        },
    };

    return (
        <section id="pricing" className="py-16 bg-neutral-50">
            <div className="container mx-auto px-4">
                <div className="text-center max-w-2xl mx-auto mb-12">
                    <h2 className="text-3xl font-bold mb-4">{t('pricing.title')}</h2>
                    <p className="text-neutral-600 text-lg">{t('pricing.description')}</p>
                </div>

                <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8 items-stretch">
                    <PricingCard 
                        plan="Community"
                        price={plans.community.price}
                        period={t('pricing.period.monthly')}
                        features={plans.community.features}
                    />
                    <PricingCard 
                        plan="Pro"
                        price={plans.pro.price}
                        period={t('pricing.period.monthly')}
                        features={plans.pro.features}
                        isFeatured
                    />
                </div>
            </div>
        </section>
    );
};

export default PricingSection;