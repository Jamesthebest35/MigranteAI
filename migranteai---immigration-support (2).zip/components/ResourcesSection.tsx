
import React, { useState, useMemo } from 'react';
import type { LinkResource } from '../types';
import { allResources, resourceCategories } from '../data/resources';
import { useTranslation } from '../contexts/LanguageContext';
import LinkIcon from './icons/LinkIcon';

const LinkResourceCard: React.FC<{ resource: LinkResource }> = ({ resource }) => {
    const { t } = useTranslation();
    return (
        <div className="border border-gray-200 rounded-lg p-4 bg-white hover:shadow-md transition-shadow duration-300 flex flex-col h-full">
            <div className="flex-grow">
                <span className={`inline-block px-2 py-0.5 text-xs font-medium rounded-full mb-2 bg-blue-100 text-blue-800`}>
                    {t(`resources.categories.${resource.category.toLowerCase().replace(' & ', '_')}`)}
                </span>
                <h4 className="font-bold text-neutral-800">{resource.name}</h4>
                <p className="text-sm text-neutral-600 mt-1">{resource.description}</p>
            </div>
            <a 
                href={resource.url} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="mt-4 inline-flex items-center text-primary font-medium group"
            >
                {t('resources.visitSite')}
                <LinkIcon className="h-4 w-4 ml-1.5 group-hover:translate-x-1 transition-transform" />
            </a>
        </div>
    );
};

const ResourcesSection: React.FC = () => {
    const { t } = useTranslation();
    const [searchTerm, setSearchTerm] = useState('');
    const [activeCategory, setActiveCategory] = useState('All');
    const [currentPage, setCurrentPage] = useState(1);
    const resourcesPerPage = 8;

    const translatedResources = useMemo(() => allResources.map(resource => ({
        ...resource,
        name: t(`resources.data.${resource.name}.name`),
        description: t(`resources.data.${resource.name}.description`),
    })), [t]);

    const filteredResources = useMemo(() => {
        return translatedResources.filter(resource => {
            const matchesCategory = activeCategory === 'All' || resource.category === activeCategory;
            const matchesSearch = searchTerm === '' || 
                resource.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                resource.description.toLowerCase().includes(searchTerm.toLowerCase());
            return matchesCategory && matchesSearch;
        });
    }, [translatedResources, activeCategory, searchTerm]);

    const paginatedResources = useMemo(() => {
        const startIndex = (currentPage - 1) * resourcesPerPage;
        return filteredResources.slice(startIndex, startIndex + resourcesPerPage);
    }, [filteredResources, currentPage, resourcesPerPage]);

    const totalPages = Math.ceil(filteredResources.length / resourcesPerPage);

    const handleCategoryClick = (category: string) => {
        setActiveCategory(category);
        setCurrentPage(1);
    };
    
    const handlePageChange = (newPage: number) => {
        if (newPage >= 1 && newPage <= totalPages) {
            setCurrentPage(newPage);
        }
    };
    
    return (
        <section id="resources" className="py-16 bg-neutral-50">
            <div className="container mx-auto px-4">
                <div className="text-center max-w-2xl mx-auto mb-12">
                    <h2 className="text-3xl font-bold mb-4">{t('resources.title')}</h2>
                    <p className="text-neutral-600 text-lg">{t('resources.description')}</p>
                </div>

                <div className="bg-white rounded-xl shadow-sm p-6 border border-neutral-200">
                    <div className="flex flex-col md:flex-row gap-4 mb-6">
                        <div className="relative flex-grow">
                             <input 
                                type="text" 
                                placeholder={t('resources.searchPlaceholder')} 
                                value={searchTerm}
                                onChange={(e) => {
                                    setSearchTerm(e.target.value);
                                    setCurrentPage(1);
                                }}
                                className="w-full border border-gray-300 rounded-lg py-2 pl-10 pr-4 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent" 
                            />
                            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                                </svg>
                            </div>
                        </div>
                    </div>
                    
                    <div className="flex flex-wrap gap-2 mb-8">
                        {['All', ...resourceCategories].map(category => (
                            <button 
                                key={category}
                                onClick={() => handleCategoryClick(category)}
                                className={`px-3 py-1 text-sm font-medium rounded-full transition-colors ${
                                    activeCategory === category 
                                    ? 'bg-primary text-white' 
                                    : 'bg-neutral-100 text-neutral-700 hover:bg-neutral-200'
                                }`}
                            >
                               {category === 'All' ? t('resources.categories.all') : t(`resources.categories.${category.toLowerCase().replace(' & ', '_')}`)}
                            </button>
                        ))}
                    </div>

                    {filteredResources.length > 0 ? (
                        <>
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                                {paginatedResources.map((resource) => (
                                    <LinkResourceCard key={resource.name} resource={resource} />
                                ))}
                            </div>

                            <div className="flex flex-col sm:flex-row justify-between items-center mt-8 pt-4 border-t border-neutral-200">
                                <p className="text-sm text-neutral-600 mb-4 sm:mb-0">
                                    {t('resources.pagination.showing')} 
                                    <span className="font-medium">{(currentPage - 1) * resourcesPerPage + 1}</span>-
                                    <span className="font-medium">{Math.min(currentPage * resourcesPerPage, filteredResources.length)}</span> {t('resources.pagination.of')} <span className="font-medium">{filteredResources.length}</span> {t('resources.pagination.results')}
                                </p>
                                <div className="flex items-center space-x-2">
                                    <button onClick={() => handlePageChange(currentPage - 1)} disabled={currentPage === 1} className="px-3 py-1 border border-gray-300 rounded-md text-sm disabled:opacity-50">
                                        {t('resources.pagination.previous')}
                                    </button>
                                    <span className="text-sm text-neutral-600">
                                        {t('resources.pagination.page')} <span className="font-medium">{currentPage}</span> / {totalPages}
                                    </span>
                                    <button onClick={() => handlePageChange(currentPage + 1)} disabled={currentPage === totalPages} className="px-3 py-1 border border-gray-300 rounded-md text-sm disabled:opacity-50">
                                        {t('resources.pagination.next')}
                                    </button>
                                </div>
                            </div>
                        </>
                    ) : (
                        <div className="text-center py-12">
                            <h3 className="text-xl font-medium text-neutral-700">{t('resources.noResults.title')}</h3>
                            <p className="text-neutral-500 mt-2">{t('resources.noResults.description')}</p>
                        </div>
                    )}
                </div>
            </div>
        </section>
    );
};

export default ResourcesSection;
