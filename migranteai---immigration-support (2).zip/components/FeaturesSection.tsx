
import React from 'react';
import { getFeatures } from '../constants';
import ChatIcon from './icons/ChatIcon';
import ResourcesIcon from './icons/ResourcesIcon';
import TranslateIcon from './icons/TranslateIcon';
import { useTranslation } from '../contexts/LanguageContext';

const iconMap: { [key: string]: React.FC<React.SVGProps<SVGSVGElement>> } = {
    ChatIcon,
    ResourcesIcon,
    TranslateIcon,
};

const colorMap: { [key: string]: { bg: string, text: string } } = {
    blue: { bg: 'bg-blue-100', text: 'text-primary' },
    orange: { bg: 'bg-orange-100', text: 'text-secondary' },
    green: { bg: 'bg-green-100', text: 'text-success' },
};

interface FeatureCardProps {
    icon: string;
    title: string;
    description: string;
    linkText: string;
    linkHref: string;
    color: string;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ icon, title, description, linkText, linkHref, color }) => {
    const IconComponent = iconMap[icon];
    const colors = colorMap[color] || colorMap.blue;

    return (
        <div className="p-6 rounded-xl border border-neutral-200 bg-white hover:shadow-lg transition-all duration-300 flex flex-col">
            <div className={`w-12 h-12 rounded-full ${colors.bg} flex items-center justify-center mb-4`}>
                <IconComponent className={`h-6 w-6 ${colors.text}`} />
            </div>
            <h3 className="text-xl font-bold mb-3">{title}</h3>
            <p className="text-neutral-600 mb-4 flex-grow">{description}</p>
            <a href={linkHref} className="text-primary font-medium inline-flex items-center group">
                {linkText}
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5l7 7-7 7" />
                </svg>
            </a>
        </div>
    );
};

const FeaturesSection: React.FC = () => {
    const { t } = useTranslation();
    const features = getFeatures(t);
    return (
        <section id="features" className="py-16 bg-neutral-50">
            <div className="container mx-auto px-4">
                <h2 className="text-3xl font-bold text-center mb-12">{t('features.title')}</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {features.map((feature, index) => (
                        <FeatureCard key={index} {...feature} />
                    ))}
                </div>
            </div>
        </section>
    );
};

export default FeaturesSection;
