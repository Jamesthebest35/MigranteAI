// FIX: Implemented the Chat component to resolve import errors.
import React, { useState, useRef, useEffect } from 'react';
import { useTranslation } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';
import { getChatResponse } from '../services/geminiService';
import type { ChatMessage } from '../types';

interface ChatProps {
    isDemoInstance?: boolean;
}

const DemoOverlay: React.FC = () => {
    const { t } = useTranslation();
    const { startDemo } = useAuth();
    return (
        <div className="absolute inset-0 bg-white/30 backdrop-blur-sm rounded-xl z-10 flex flex-col items-center justify-center p-4 text-center">
            <h4 className="font-bold text-lg text-neutral-800">{t('chat.demo.title')}</h4>
            <p className="text-neutral-600 my-2">{t('chat.demo.description')}</p>
            <button 
                onClick={startDemo}
                className="bg-secondary hover:bg-orange-700 text-white font-bold py-2 px-5 rounded-lg transition-colors duration-300"
            >
                {t('demo.try')}
            </button>
        </div>
    );
};

const Chat: React.FC<ChatProps> = ({ isDemoInstance = false }) => {
    const { t, language } = useTranslation();
    const { isPro } = useAuth();
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);
    
    const showOverlay = !isPro && !isDemoInstance;

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    useEffect(scrollToBottom, [messages]);
    
    useEffect(() => {
        setMessages([]); // Clear chat when language changes
    }, [language]);


    const handleSend = async () => {
        if (input.trim() === '' || isLoading) return;

        const userMessage: ChatMessage = { role: 'user', text: input };
        setMessages(prev => [...prev, userMessage]);
        setInput('');
        setIsLoading(true);

        try {
            const responseText = await getChatResponse(input, language);
            const modelMessage: ChatMessage = { role: 'model', text: responseText };
            setMessages(prev => [...prev, modelMessage]);
        } catch (error) {
            console.error(error);
            const errorMessage: ChatMessage = { role: 'model', text: t('chat.errorMessage') };
            setMessages(prev => [...prev, errorMessage]);
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className={`w-full max-w-lg mx-auto bg-white rounded-xl shadow-2xl flex flex-col h-[60vh] relative ${showOverlay ? 'overflow-hidden' : ''}`}>
            {showOverlay && <DemoOverlay />}
            <div className={`p-4 border-b ${showOverlay ? 'blur-sm' : ''}`}>
                <h3 className="text-lg font-bold text-neutral-800">{t('chat.title')}</h3>
                <p className="text-sm text-neutral-500">{t('chat.subtitle')}</p>
            </div>
            <div className={`flex-1 p-4 overflow-y-auto bg-neutral-50 ${showOverlay ? 'blur-sm' : ''}`}>
                {messages.length === 0 && (
                     <div className="flex flex-col items-center justify-center h-full text-center text-neutral-500">
                        <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center text-primary mb-2">
                           <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>
                        </div>
                        <p>{t('chat.welcome')}</p>
                    </div>
                )}
                {messages.map((msg, index) => (
                    <div key={index} className={`flex mb-4 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`rounded-lg px-4 py-2 max-w-xs lg:max-w-md ${msg.role === 'user' ? 'bg-primary text-white' : 'bg-neutral-200 text-neutral-800'}`}>
                            <p className="text-sm" style={{ whiteSpace: 'pre-wrap' }}>{msg.text}</p>
                        </div>
                    </div>
                ))}
                {isLoading && (
                    <div className="flex justify-start">
                         <div className="rounded-lg px-4 py-2 bg-neutral-200 text-neutral-800">
                            <div className="flex items-center space-x-1">
                                <span className="h-2 w-2 bg-neutral-500 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                                <span className="h-2 w-2 bg-neutral-500 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                                <span className="h-2 w-2 bg-neutral-500 rounded-full animate-bounce"></span>
                            </div>
                        </div>
                    </div>
                )}
                <div ref={messagesEndRef} />
            </div>
            <div className={`p-4 border-t ${showOverlay ? 'blur-sm' : ''}`}>
                <div className="flex items-center space-x-2">
                    <input
                        type="text"
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                        placeholder={t('chat.placeholder')}
                        className="w-full border border-gray-300 rounded-lg py-2 px-4 focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent text-sm"
                        disabled={isLoading || showOverlay}
                    />
                    <button
                        onClick={handleSend}
                        disabled={isLoading || input.trim() === '' || showOverlay}
                        className="bg-primary text-white rounded-lg p-2 disabled:bg-primary/50 disabled:cursor-not-allowed hover:bg-blue-800 transition-colors"
                    >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                            <path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.428A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" />
                        </svg>
                    </button>
                </div>
            </div>
        </div>
    );
};

export default Chat;