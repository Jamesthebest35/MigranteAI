import React, { useState } from 'react';
import { useTranslation } from '../contexts/LanguageContext';
import { useAuth } from '../contexts/AuthContext';

const Header: React.FC = () => {
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const { language, setLanguage, t } = useTranslation();
    const { user, login, logout, isPro } = useAuth();

    const handleLanguageChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        setLanguage(e.target.value as 'en' | 'es');
    };

    return (
        <header className="bg-white shadow-sm sticky top-0 z-20">
            <div className="container mx-auto px-4 py-4 flex justify-between items-center">
                <div className="flex items-center space-x-2 cursor-pointer" onClick={() => window.scrollTo(0, 0)}>
                    <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-white font-bold text-xl">M</div>
                    <span className="text-xl font-bold text-primary">MigranteAI</span>
                </div>
                
                <nav className="hidden md:flex space-x-6 items-center">
                    <a href="#features" className="font-medium text-neutral-600 hover:text-primary">{t('header.features')}</a>
                    <a href="#resources" className="font-medium text-neutral-600 hover:text-primary">{t('header.resources')}</a>
                    <a href="#translate" className="font-medium text-neutral-600 hover:text-primary">{t('header.translate')}</a>
                    <a href="#pricing" className="font-medium text-neutral-600 hover:text-primary">{t('header.pricing')}</a>
                </nav>
                
                <div className="flex items-center space-x-2 md:space-x-4">
                    <div className="relative">
                        <select 
                            value={language}
                            onChange={handleLanguageChange}
                            className="appearance-none bg-white border border-gray-300 rounded-lg px-3 py-2 pr-8 text-sm focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
                            aria-label={t('header.languageSelectorLabel')}
                        >
                            <option value="en">English</option>
                            <option value="es">Español</option>
                        </select>
                        <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-gray-700">
                            <svg className="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
                        </div>
                    </div>
                     {user ? (
                        <>
                           {!isPro && <a href="#pricing" className="hidden sm:inline-block bg-secondary hover:bg-orange-700 text-white font-bold py-2 px-4 rounded-lg text-sm transition-colors duration-300">{t('header.goPro')}</a>}
                           <button onClick={logout} className="hidden sm:inline-block font-medium text-neutral-600 hover:text-primary text-sm">{t('header.logout')}</button>
                        </>
                    ) : (
                        <button onClick={login} className="bg-primary hover:bg-blue-800 text-white font-bold py-2 px-4 rounded-lg text-sm transition-colors duration-300">{t('header.login')}</button>
                    )}
                    <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)} aria-label={t('header.menuAriaLabel')}>
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16" />
                        </svg>
                    </button>
                </div>
            </div>
             {isMenuOpen && (
                <div className="md:hidden px-4 pb-4">
                    <a href="#features" className="block py-2 font-medium text-neutral-600 hover:text-primary" onClick={() => setIsMenuOpen(false)}>{t('header.features')}</a>
                    <a href="#resources" className="block py-2 font-medium text-neutral-600 hover:text-primary" onClick={() => setIsMenuOpen(false)}>{t('header.resources')}</a>
                    <a href="#translate" className="block py-2 font-medium text-neutral-600 hover:text-primary" onClick={() => setIsMenuOpen(false)}>{t('header.translate')}</a>
                    <a href="#pricing" className="block py-2 font-medium text-neutral-600 hover:text-primary" onClick={() => setIsMenuOpen(false)}>{t('header.pricing')}</a>
                    <div className="border-t mt-2 pt-2">
                        {user ? (
                            <>
                                {!isPro && <a href="#pricing" className="block w-full text-center bg-secondary hover:bg-orange-700 text-white font-bold py-2 px-4 rounded-lg text-sm transition-colors duration-300 mb-2" onClick={() => setIsMenuOpen(false)}>{t('header.goPro')}</a>}
                                <button onClick={() => { logout(); setIsMenuOpen(false); }} className="w-full text-center font-medium text-neutral-600 hover:text-primary py-2">{t('header.logout')}</button>
                            </>
                        ) : (
                           <button onClick={() => { login(); setIsMenuOpen(false); }} className="w-full bg-primary hover:bg-blue-800 text-white font-bold py-2 px-4 rounded-lg text-sm transition-colors duration-300">{t('header.login')}</button>
                        )}
                    </div>
                </div>
            )}
        </header>
    );
};

export default Header;