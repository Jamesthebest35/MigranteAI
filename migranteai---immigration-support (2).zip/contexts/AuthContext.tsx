// FIX: Implemented the AuthContext to resolve import errors.
import React, { createContext, useState, useContext, useMemo, useCallback } from 'react';

interface User {
  name: string;
  email: string;
}

interface AuthContextType {
  user: User | null;
  isPro: boolean;
  isDemo: boolean;
  login: () => void;
  logout: () => void;
  upgrade: () => void;
  startDemo: () => void;
  endDemo: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isPro, setIsPro] = useState(false);
  const [isDemo, setIsDemo] = useState(false);

  const login = useCallback(() => {
    setUser({ name: 'Demo User', email: 'demo@example.com' });
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    setIsPro(false);
    setIsDemo(false);
  }, []);
  
  const upgrade = useCallback(() => {
    if (user) {
        setIsPro(true);
        setIsDemo(false);
    } else {
        login();
        // A real app would redirect to a checkout page,
        // then set isPro upon successful payment.
        // For this demo, we'll just log in.
    }
  }, [user, login]);

  const startDemo = useCallback(() => {
    setIsDemo(true);
  }, []);

  const endDemo = useCallback(() => {
    setIsDemo(false);
  }, []);

  const value = useMemo(() => ({
    user,
    isPro,
    isDemo,
    login,
    logout,
    upgrade,
    startDemo,
    endDemo,
  }), [user, isPro, isDemo, login, logout, upgrade, startDemo, endDemo]);

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};