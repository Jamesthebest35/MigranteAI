
import React, { createContext, useState, useContext, useMemo, useCallback } from 'react';
import { translations } from '../translations';

type Language = 'en' | 'es';

interface LanguageContextType {
  language: Language;
  setLanguage: (language: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('en');

  const t = useCallback((key: string): string => {
    const keys = key.split('.');
    let result: any = translations[language];
    try {
      for (const k of keys) {
        result = result[k];
      }
    } catch (e) {
      result = undefined;
    }

    if (result !== undefined) {
      return result;
    }

    // Fallback to English
    let fallbackResult: any = translations.en;
    try {
      for (const k of keys) {
        fallbackResult = fallbackResult[k];
      }
      return fallbackResult || key;
    } catch (e) {
      return key;
    }
  }, [language]);
  
  const value = useMemo(() => ({
    language,
    setLanguage,
    t
  }), [language, t]);

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useTranslation = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useTranslation must be used within a LanguageProvider');
  }
  return context;
};
