import { GoogleGenAI, Chat } from "@google/genai";

// =================================================================================
// CRITICAL SECURITY WARNING
// =================================================================================
// This client-side API key is for demonstration purposes only.
// In a production environment, this key MUST be removed from the frontend code.
// All calls to the GoogleGenAI API should be proxied through a secure backend server
// that you control. Your backend server will then append the API key to requests
// before sending them to Google. This prevents unauthorized use of your API key
// and protects your application from abuse.
// =================================================================================

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const chatConfigs = {
    en: {
        systemInstruction: "You are MigranteAI, a helpful and compassionate AI assistant for immigrants. Provide clear, supportive, and accurate information about immigration processes. Always speak in a friendly and encouraging tone. Do not provide legal advice, and if asked for it, gently decline and recommend consulting a qualified immigration lawyer. Respond in English.",
    },
    es: {
        systemInstruction: "Eres MigranteAI, un asistente de IA servicial y compasivo para inmigrantes. Proporciona información clara, de apoyo y precisa sobre los procesos de inmigración. Habla siempre en un tono amable y alentador. No ofrezcas asesoramiento legal y, si te lo piden, declina amablemente y recomienda consultar a un abogado de inmigración cualificado. Responde en español.",
    }
};

const chats: { [key: string]: Chat } = {};

const getChatForLanguage = (language: 'en' | 'es'): Chat => {
    if (!chats[language]) {
        chats[language] = ai.chats.create({
            model: 'gemini-2.5-flash',
            config: chatConfigs[language],
        });
    }
    return chats[language];
};

export const getChatResponse = async (message: string, language: 'en' | 'es'): Promise<string> => {
    // In production, this function should make a fetch call to your own backend API
    // (e.g., POST /api/chat) which then securely calls the Gemini API.
    try {
        const chat = getChatForLanguage(language);
        const response = await chat.sendMessage({ message });
        return response.text;
    } catch (error) {
        console.error("Error getting chat response from Gemini:", error);
        const errorMessage = language === 'es' 
            ? "Lo siento, estoy teniendo problemas para conectarme en este momento. Por favor, inténtalo de nuevo más tarde."
            : "I'm sorry, I'm having trouble connecting right now. Please try again later.";
        return errorMessage;
    }
};

export const translateDocument = async (fileContent: string, fromLang: string, toLang: string): Promise<string> => {
    // In production, this function should make a fetch call to your own backend API
    // (e.g., POST /api/translate) which then securely calls the Gemini API.
    const prompt = `Translate the following document from ${fromLang} to ${toLang}. Preserve the original formatting as much as possible.\n\nDOCUMENT:\n${fileContent}`;
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt
        });
        return response.text;
    } catch (error) {
        console.error("Error translating document:", error);
        return "Error: Could not translate the document. Please try again.";
    }
};