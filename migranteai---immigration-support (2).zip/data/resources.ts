import type { LinkResource } from '../types';

export const resourceCategories = [
    'Official Government',
    'Legal Aid',
    'Non-Profit Support',
    'Community & Integration',
    'News & Updates',
    'Employment & Education',
];

// FIX: Corrected the type to Omit<LinkResource, 'description'>. The previous type Omit<LinkResource, 'name' | 'description'> incorrectly excluded the 'name' property, which is used as a translation key.
const baseResources: Omit<LinkResource, 'description'>[] = [
    // Official Government
    { name: 'USCIS', url: 'https://www.uscis.gov/', category: 'Official Government' },
    { name: 'StateDeptVisa', url: 'https://travel.state.gov/content/travel/en/us-visas.html', category: 'Official Government' },
    { name: 'ICE', url: 'https://www.ice.gov/', category: 'Official Government' },
    { name: 'CBP', url: 'https://www.cbp.gov/', category: 'Official Government' },
    { name: 'EOIR', url: 'https://www.justice.gov/eoir', category: 'Official Government' },
    { name: 'SSA', url: 'https://www.ssa.gov/pubs/EN-05-10107.pdf', category: 'Official Government' },
    { name: 'IRSITIN', url: 'https://www.irs.gov/individuals/individual-taxpayer-identification-number', category: 'Official Government' },
    { name: 'DVLottery', url: 'https://dvprogram.state.gov/', category: 'Official Government' },
    { name: 'USAGov', url: 'https://www.usa.gov/immigration-and-citizenship', category: 'Official Government' },
    { name: 'EmbassyFinder', url: 'https://www.usembassy.gov/', category: 'Official Government' },
    
    // Legal Aid
    { name: 'AILA', url: 'https://www.ailalawyer.com/', category: 'Legal Aid' },
    { name: 'ImmigrationAdvocates', url: 'https://www.immigrationadvocates.org/', category: 'Legal Aid' },
    { name: 'ProBonoNet', url: 'https://www.probono.net/our-work/immigration/', category: 'Legal Aid' },
    { name: 'FindLawImmigration', url: 'https://www.findlaw.com/immigration.html', category: 'Legal Aid' },
    { name: 'NILC', url: 'https://www.nilc.org/', category: 'Legal Aid' },
    { name: 'ILRC', url: 'https://www.ilrc.org/', category: 'Legal Aid' },
    { name: 'JustiaImmigration', url: 'https://www.justia.com/immigration/', category: 'Legal Aid' },
    { name: 'CLINIC', url: 'https://cliniclegal.org/', category: 'Legal Aid' },
    { name: 'TheRefugeeAndImmigrantCenter', url: 'https://www.raicestexas.org/', category: 'Legal Aid' },
    { name: 'FlorenceProject', url: 'https://firrp.org/', category: 'Legal Aid' },

    // Non-Profit Support
    { name: 'ImmigrantHelp', url: 'https://www.immigranthelp.org/', category: 'Non-Profit Support' },
    { name: 'USAHello', url: 'https://usahello.org/', category: 'Non-Profit Support' },
    { name: 'UpwardlyGlobal', url: 'https://www.upwardlyglobal.org/', category: 'Non-Profit Support' },
    { name: 'IRC', url: 'https://www.rescue.org/', category: 'Non-Profit Support' },
    { name: 'HIAS', url: 'https://www.hias.org/', category: 'Non-Profit Support' },
    { name: 'InformedImmigrant', url: 'https://www.informedimmigrant.com/', category: 'Non-Profit Support' },
    { name: 'UNHCRUSA', url: 'https://www.unhcr.org/en-us/', category: 'Non-Profit Support' },
    { name: 'NewAmericanEconomy', url: 'https://www.newamericaneconomy.org/', category: 'Non-Profit Support' },
    { name: 'WelcomingAmerica', url: 'https://welcomingamerica.org/', category: 'Non-Profit Support' },
    { name: 'ChurchWorldService', url: 'https://cwsglobal.org/', category: 'Non-Profit Support' },

    // Community & Integration
    { name: 'WeAreAllAmerica', url: 'https://www.weareallamerica.org/', category: 'Community & Integration' },
    { name: 'WorldEducationServices', url: 'https://www.wes.org/', category: 'Community & Integration' },
    { name: 'NationalPartnershipForNewAmericans', url: 'https://partnershipfornewamericans.org/', category: 'Community & Integration' },
    { name: 'CulturalOrientationResourceExchange', url: 'https://coresourceexchange.org/', category: 'Community & Integration' },
    { name: 'TheImmigrantLearningCenter', url: 'https://www.ilctr.org/', category: 'Community & Integration' },
    { name: 'ImmigrantsRising', url: 'https://immigrantsrising.org/', category: 'Community & Integration' },
    { name: 'MyUSCIS', url: 'https://my.uscis.gov/', category: 'Community & Integration' },
    { name: 'TheWelcomeProject', url: 'https://www.welcomeproject.org/', category: 'Community & Integration' },
    { name: 'BridgeUS', url: 'https://www.bridgeusa.org/', category: 'Community & Integration' },
    { name: 'TamarindoPodcast', url: 'https://tamarindopodcast.com/', category: 'Community & Integration' },

    // News & Updates
    { name: 'ImmigrationImpact', url: 'https://immigrationimpact.com/', category: 'News & Updates' },
    { name: 'MigrationPolicyInstitute', url: 'https://www.migrationpolicy.org/', category: 'News & Updates' },
    { name: 'PewResearchHispanic', url: 'https://www.pewresearch.org/topic/hispanic-americans/', category: 'News & Updates' },
    { name: 'CISorg', url: 'https://cis.org/', category: 'News & Updates' },
    { name: 'Boundless', url: 'https://www.boundless.com/', category: 'News & Updates' },
    { name: 'RollCallImmigration', url: 'https://rollcall.com/category/policy/immigration/', category: 'News & Updates' },
    { name: 'TheHillImmigration', url: 'https://thehill.com/policy/immigration/', category: 'News & Updates' },
    { name: 'PoliticoImmigration', url: 'https://www.politico.com/news/immigration', category: 'News & Updates' },
    { name: 'NPRImmigration', url: 'https://www.npr.org/sections/immigration/', category: 'News & Updates' },
    { name: 'NYTImmigration', url: 'https://www.nytimes.com/topic/subject/immigration-and-emigration', category: 'News & Updates' },

    // Employment & Education
    { name: 'USALearns', url: 'https://www.usalearns.org/', category: 'Employment & Education' },
    { name: 'OINetOnline', url: 'https://www.onetonline.org/', category: 'Employment & Education' },
    { name: 'CareerOneStop', url: 'https://www.careeronestop.org/', category: 'Employment & Education' },
    { name: 'USDeptOfEdNewcomers', url: 'https://www2.ed.gov/about/offices/list/oela/newcomers-toolkit/index.html', category: 'Employment & Education' },
    { name: 'Coursera', url: 'https://www.coursera.org/', category: 'Employment & Education' },
    { name: 'EdX', url: 'https://www.edx.org/', category: 'Employment & Education' },
    { name: 'KhanAcademy', url: 'https://www.khanacademy.org/', category: 'Employment & Education' },
    { name: 'GCFLearnFree', url: 'https://edu.gcfglobal.org/en/', category: 'Employment & Education' },
    { name: 'Codecademy', url: 'https://www.codecademy.com/', category: 'Employment & Education' },
    { name: 'LinkedInLearning', url: 'https://www.linkedin.com/learning', category: 'Employment & Education' },
];

// Duplicate the base resources to reach 150 items
// FIX: Corrected the type to Omit<LinkResource, 'description'> to match the type of `baseResources` and the objects being created, which include a 'name' property.
export const allResources: Omit<LinkResource, 'description'>[] = [];
for (let i = 0; allResources.length < 150; i++) {
    const resource = baseResources[i % baseResources.length];
    allResources.push({
        ...resource,
        name: `${resource.name}${Math.floor(i / baseResources.length) || ''}`,
    });
}
