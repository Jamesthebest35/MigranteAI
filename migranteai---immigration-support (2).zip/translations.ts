// FIX: Implemented the translations object to resolve import errors.
export const translations = {
  en: {
    header: {
      features: 'Features',
      resources: 'Resources',
      translate: 'Translate',
      pricing: 'Pricing',
      login: 'Login',
      logout: 'Logout',
      goPro: 'Go Pro',
      languageSelectorLabel: 'Select language',
      menuAriaLabel: 'Open menu',
    },
    hero: {
      title: 'Your Compassionate Guide to Navigating Immigration',
      subtitle: 'Get instant, reliable answers to your questions, find resources, and translate documents with our AI-powered assistant.',
      ctaChat: 'Ask a Question',
      ctaResources: 'Explore Resources',
    },
    trustIndicators: {
      immigrantsHelped: 'Immigrants Helped',
      resourcesAvailable: 'Verified Resources',
      supportAvailable: 'Support Available',
    },
    features: {
      title: 'How MigranteAI Can Help You',
      chat: {
        title: 'Instant AI Chat',
        description: 'Get clear, step-by-step answers to your immigration questions, 24/7. Our AI is trained on up-to-date information to provide reliable guidance.',
        linkText: 'Start chatting',
      },
      resources: {
        title: 'Curated Resource Hub',
        description: 'Access a vetted database of legal aid services, government links, community support groups, and educational materials in your area.',
        linkText: 'Find resources',
      },
      translate: {
        title: 'Document Translation',
        description: 'Securely upload and translate important documents. Our AI preserves formatting to ensure accuracy and readability.',
        linkText: 'Translate a document',
      },
    },
    testimonials: {
      title: 'Trusted by Immigrants Like You',
      data: {
        maria: {
          quote: "MigranteAI gave me the clear information I needed to understand my visa process. It felt like I had a knowledgeable friend helping me.",
        },
        ahmed: {
          quote: "The resource finder was incredible. I found a local non-profit that offered free legal advice, which was a huge help for my family.",
        },
        wei: {
          quote: "Translating documents was always a worry, but this tool is fast, accurate, and so easy to use. It saved me time and money.",
        },
      }
    },
    chat: {
        title: 'MigranteAI Assistant',
        subtitle: 'Ask me anything about immigration',
        placeholder: 'Type your question here...',
        welcome: 'Hello! How can I assist you with your immigration journey today?',
        errorMessage: 'Sorry, I encountered an error. Please try again.',
        demo: {
            title: 'This is a Pro Feature',
            description: 'Experience the full power of our AI assistant.',
        }
    },
    resources: {
        title: 'Explore Our Resource Library',
        description: 'Find trusted organizations, official links, and helpful guides to support your journey.',
        visitSite: 'Visit Site',
        searchPlaceholder: 'Search for resources...',
        categories: {
            all: 'All',
            'official government': 'Official Government',
            'legal aid': 'Legal Aid',
            'non-profit support': 'Non-Profit Support',
            'community & integration': 'Community & Integration',
            'news & updates': 'News & Updates',
            'employment & education': 'Employment & Education',
        },
        pagination: {
            showing: 'Showing',
            of: 'of',
            results: 'results',
            previous: 'Previous',
            next: 'Next',
            page: 'Page',
        },
        noResults: {
            title: 'No resources found',
            description: 'Try adjusting your search or category filters.',
        },
        data: {
            USCIS: { name: "U.S. Citizenship and Immigration Services (USCIS)", description: "Official source for immigration forms, case status, and policy information." },
            StateDeptVisa: { name: "U.S. Department of State - Visa Information", description: "Information on visa types, application processes, and the visa bulletin." },
            ICE: { name: "U.S. Immigration and Customs Enforcement (ICE)", description: "Enforces federal laws governing border control, customs, trade, and immigration." },
            CBP: { name: "U.S. Customs and Border Protection (CBP)", description: "Manages, controls, and protects the nation's borders." },
            EOIR: { name: "Executive Office for Immigration Review (EOIR)", description: "Adjudicates immigration cases by interpreting and administering Federal immigration laws." },
            AILA: { name: "American Immigration Lawyers Association (AILA)", description: "National association of immigration lawyers providing resources and legal assistance." },
            ImmigrationAdvocates: { name: "Immigration Advocates Network", description: "A non-profit organization providing support and resources for immigration advocates." },
            ImmigrantHelp: { name: "ImmigrantHelp.org", description: "Connects immigrants with trusted nonprofit legal services." }
            // In a real app, all 150+ resources would be here
        }
    },
    translation: {
        title: 'Easy Document Translation',
        description: 'Translate your documents securely and accurately. Simply upload your file to get started.',
        originalDocument: 'Original Document',
        translatedDocument: 'Translated Document',
        dragAndDrop: 'Drag & drop a file here, or click to select',
        supportedFiles: 'Supported files: .txt, .md, .html',
        translating: 'Translating...',
        translationWillAppearHere: 'Translation will appear here',
        secure: 'Your documents are private and secure.',
        translateButton: 'Translate',
        downloadButton: 'Download',
        error: 'An error occurred during translation. Please try again.',
        demo: {
            title: 'Unlock Unlimited Document Translation',
            description: 'The Pro plan gives you access to translate longer documents, with priority processing.',
        }
    },
    pricing: {
        title: 'Choose Your Plan',
        description: 'Get started for free or unlock powerful features with our Pro plan.',
        period: {
            monthly: '/ month',
        },
        cta: {
            signUp: 'Sign Up',
            upgrade: 'Upgrade to Pro',
            getStarted: 'Get Started',
            currentPlan: 'Current Plan',
        },
        plans: {
            community: {
                price: 'Free',
                description: 'For individuals getting started.',
                features: {
                    feature1: '5 AI chat questions per day',
                    feature2: 'Access to all public resources',
                    feature3: '1 document translation per month (up to 500 words)',
                    feature4: 'Community support',
                },
            },
            pro: {
                description: 'For those needing more support.',
                features: {
                    feature1: 'Unlimited AI chat questions',
                    feature2: 'Advanced resource filtering',
                    feature3: '20 document translations per month (up to 5,000 words)',
                    feature4: 'Priority email support',
                    feature5: 'Save chat history',
                },
            },
        },
    },
    footer: {
        tagline: 'Your compassionate guide to navigating immigration.',
        features: {
            title: 'Features',
            chat: 'AI Chat',
            resources: 'Resources',
            translate: 'Translation',
        },
        legal: {
            title: 'Legal',
            privacy: 'Privacy Policy',
            terms: 'Terms of Service',
            disclaimer: 'Disclaimer',
        },
        contact: {
            title: 'Contact',
        },
        copyright: 'All Rights Reserved.',
        legalDisclaimer: 'MigranteAI does not provide legal advice. Consult with a qualified immigration attorney for your specific situation.'
    },
    demo: {
        title: 'Pro Tools Hub',
        description: 'You are now in Demo Mode. Test drive our most powerful features.',
        end: 'End Demo',
        upgrade: 'Upgrade to Pro',
        try: 'Try the Pro Demo',
        chatTab: 'AI Assistant',
        translateTab: 'Document Translator',
    }
  },
  es: {
    header: {
      features: 'Funciones',
      resources: 'Recursos',
      translate: 'Traducir',
      pricing: 'Precios',
      login: 'Iniciar Sesión',
      logout: 'Cerrar Sesión',
      goPro: 'Hazte Pro',
      languageSelectorLabel: 'Seleccionar idioma',
      menuAriaLabel: 'Abrir menú',
    },
    hero: {
      title: 'Tu Guía Compasiva para Navegar la Inmigración',
      subtitle: 'Obtén respuestas instantáneas y confiables, encuentra recursos y traduce documentos con nuestro asistente de IA.',
      ctaChat: 'Haz una Pregunta',
      ctaResources: 'Explorar Recursos',
    },
    trustIndicators: {
      immigrantsHelped: 'Inmigrantes Ayudados',
      resourcesAvailable: 'Recursos Verificados',
      supportAvailable: 'Soporte Disponible',
    },
    features: {
      title: 'Cómo Puede Ayudarte MigranteAI',
      chat: {
        title: 'Chat de IA Instantáneo',
        description: 'Obtén respuestas claras y paso a paso a tus preguntas de inmigración, 24/7. Nuestra IA está entrenada con información actualizada para brindar orientación confiable.',
        linkText: 'Comenzar a chatear',
      },
      resources: {
        title: 'Centro de Recursos Verificados',
        description: 'Accede a una base de datos de servicios de ayuda legal, enlaces gubernamentales, grupos de apoyo comunitario y materiales educativos en tu área.',
        linkText: 'Encontrar recursos',
      },
      translate: {
        title: 'Traducción de Documentos',
        description: 'Sube y traduce de forma segura documentos importantes. Nuestra IA preserva el formato para garantizar la precisión y la legibilidad.',
        linkText: 'Traducir un documento',
      },
    },
    testimonials: {
      title: 'Con la Confianza de Inmigrantes Como Tú',
       data: {
        maria: {
          quote: "MigranteAI me dio la información clara que necesitaba para entender mi proceso de visa. Sentí que tenía un amigo experto ayudándome.",
        },
        ahmed: {
          quote: "El buscador de recursos fue increíble. Encontré una organización local sin fines de lucro que ofrecía asesoramiento legal gratuito, lo cual fue de gran ayuda para mi familia.",
        },
        wei: {
          quote: "Traducir documentos siempre fue una preocupación, pero esta herramienta es rápida, precisa y muy fácil de usar. Me ahorró tiempo y dinero.",
        },
      }
    },
    chat: {
        title: 'Asistente MigranteAI',
        subtitle: 'Pregúntame cualquier cosa sobre inmigración',
        placeholder: 'Escribe tu pregunta aquí...',
        welcome: '¡Hola! ¿Cómo puedo ayudarte hoy con tu proceso de inmigración?',
        errorMessage: 'Lo siento, ocurrió un error. Por favor, inténtalo de nuevo.',
        demo: {
            title: 'Esta es una Función Pro',
            description: 'Experimenta todo el poder de nuestro asistente de IA.',
        }
    },
     resources: {
        title: 'Explora Nuestra Biblioteca de Recursos',
        description: 'Encuentra organizaciones de confianza, enlaces oficiales y guías útiles para apoyar tu viaje.',
        visitSite: 'Visitar Sitio',
        searchPlaceholder: 'Buscar recursos...',
        categories: {
            all: 'Todos',
            'official government': 'Gobierno Oficial',
            'legal aid': 'Ayuda Legal',
            'non-profit support': 'Apoyo de ONGs',
            'community & integration': 'Comunidad e Integración',
            'news & updates': 'Noticias y Actualizaciones',
            'employment & education': 'Empleo y Educación',
        },
        pagination: {
            showing: 'Mostrando',
            of: 'de',
            results: 'resultados',
            previous: 'Anterior',
            next: 'Siguiente',
            page: 'Página',
        },
        noResults: {
            title: 'No se encontraron recursos',
            description: 'Intenta ajustar tu búsqueda o los filtros de categoría.',
        },
        data: {
            USCIS: { name: "Servicios de Ciudadanía e Inmigración de EE. UU. (USCIS)", description: "Fuente oficial de formularios de inmigración, estado de casos e información sobre políticas." },
            StateDeptVisa: { name: "Departamento de Estado de EE. UU. - Información de Visas", description: "Información sobre tipos de visa, procesos de solicitud y el boletín de visas." },
            ICE: { name: "Servicio de Inmigración y Control de Aduanas de EE. UU. (ICE)", description: "Aplica las leyes federales que rigen el control fronterizo, aduanas, comercio e inmigración." },
            CBP: { name: "Oficina de Aduanas y Protección Fronteriza de EE. UU. (CBP)", description: "Administra, controla y protege las fronteras de la nación." },
            EOIR: { name: "Oficina Ejecutiva de Revisión de Casos de Inmigración (EOIR)", description: "Adjudica casos de inmigración interpretando y administrando las leyes federales de inmigración." },
            AILA: { name: "Asociación Americana de Abogados de Inmigración (AILA)", description: "Asociación nacional de abogados de inmigración que proporciona recursos y asistencia legal." },
            ImmigrationAdvocates: { name: "Red de Defensores de Inmigrantes", description: "Una organización sin fines de lucro que brinda apoyo y recursos para los defensores de la inmigración." },
            ImmigrantHelp: { name: "ImmigrantHelp.org", description: "Conecta a inmigrantes con servicios legales confiables y sin fines de lucro." }
        }
    },
    translation: {
        title: 'Traducción de Documentos Fácil',
        description: 'Traduce tus documentos de forma segura y precisa. Simplemente sube tu archivo para comenzar.',
        originalDocument: 'Documento Original',
        translatedDocument: 'Documento Traducido',
        dragAndDrop: 'Arrastra y suelta un archivo aquí, o haz clic para seleccionar',
        supportedFiles: 'Archivos soportados: .txt, .md, .html',
        translating: 'Traduciendo...',
        translationWillAppearHere: 'La traducción aparecerá aquí',
        secure: 'Tus documentos son privados y seguros.',
        translateButton: 'Traducir',
        downloadButton: 'Descargar',
        error: 'Ocurrió un error durante la traducción. Por favor, inténtalo de nuevo.',
        demo: {
            title: 'Desbloquea la Traducción Ilimitada de Documentos',
            description: 'El plan Pro te da acceso a traducir documentos más largos, con procesamiento prioritario.',
        }
    },
    pricing: {
        title: 'Elige Tu Plan',
        description: 'Comienza gratis o desbloquea potentes funciones con nuestro plan Pro.',
        period: {
            monthly: '/ mes',
        },
        cta: {
            signUp: 'Regístrate',
            upgrade: 'Actualizar a Pro',
            getStarted: 'Comenzar',
            currentPlan: 'Plan Actual',
        },
        plans: {
            community: {
                price: 'Gratis',
                description: 'Para personas que están comenzando.',
                features: {
                    feature1: '5 preguntas de chat de IA por día',
                    feature2: 'Acceso a todos los recursos públicos',
                    feature3: '1 traducción de documento al mes (hasta 500 palabras)',
                    feature4: 'Soporte comunitario',
                },
            },
            pro: {
                description: 'Para quienes necesitan más apoyo.',
                features: {
                    feature1: 'Preguntas de chat de IA ilimitadas',
                    feature2: 'Filtrado avanzado de recursos',
                    feature3: '20 traducciones de documentos al mes (hasta 5,000 palabras)',
                    feature4: 'Soporte prioritario por correo electrónico',
                    feature5: 'Guardar historial de chat',
                },
            },
        },
    },
    footer: {
        tagline: 'Tu guía compasiva para navegar la inmigración.',
        features: {
            title: 'Funciones',
            chat: 'Chat de IA',
            resources: 'Recursos',
            translate: 'Traducción',
        },
        legal: {
            title: 'Legal',
            privacy: 'Política de Privacidad',
            terms: 'Términos de Servicio',
            disclaimer: 'Descargo de Responsabilidad',
        },
        contact: {
            title: 'Contacto',
        },
        copyright: 'Todos los Derechos Reservados.',
        legalDisclaimer: 'MigranteAI no proporciona asesoramiento legal. Consulta con un abogado de inmigración calificado para tu situación específica.'
    },
    demo: {
        title: 'Centro de Herramientas Pro',
        description: 'Ahora estás en Modo Demo. Prueba nuestras funciones más potentes.',
        end: 'Finalizar Demo',
        upgrade: 'Hazte Pro',
        try: 'Probar el Demo Pro',
        chatTab: 'Asistente de IA',
        translateTab: 'Traductor de Documentos',
    }
  }
};